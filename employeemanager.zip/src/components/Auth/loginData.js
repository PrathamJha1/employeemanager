const loginData = [
    {
        name:"Pratham Jha",
        email:"prathamjha5683@gmail.com",
        password:"12345",
        status:"employee"
    },
    {
        name:"PJ",
        email:"abc@gmail.com",
        password:"12345",
        status:"hr"
    }
];
export default loginData;