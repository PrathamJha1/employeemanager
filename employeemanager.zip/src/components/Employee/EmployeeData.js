export const EmployeeData = [{
    name:"Pratham Jha",
    email:"prathamjha5683@gmail.com",
    phone_number:8910250031,
    address:"7B Rani Rashmoni Road,Esplanade",
    city:"Kolkata",
    state:"West Bengal",
    pin_code:700013,
    occupation:"Java Developer",
    post:"Fresher",
    ctc:"6.75",
    desk_no:"A501",
    joining_date: "12/05/2022"
}
,
{
    name:"ABC",
    email:"abc@gmail.com",
    phone_number: 9088886523,
    address:"7C Mott Lane Janbazaar",
    city:"Kolkata",
    state:"West Bengal",
    pin_code:700013,
    occupation:"C++ Developer",
    post:"Fresher",
    ctc:"9.00",
    desk_no:"B-559",
}
]