const AllEmployees = [
    {
        id:"1",
        name:"Pratham Jha",
        email:"pratham@gmail.com"
    },
    {
        id:"2",
        name:"ABC",
        email:"abc@gmail.com"
    }
];
export default AllEmployees;